# JOB TASK Update AitiCore CMS

Dokumen ini menyusun task update teknis yang mengikuti alur aplikasi `aiticore-cms`, dengan acuan utama:

- `AGENT.md`
- `CHANGELOG.md`
- struktur route aktif di `routes/web.php`
- kontrak arsitektur `route -> controller -> service -> view/database`

Fokus update disusun agar tetap sesuai prinsip:

- secure by default
- thin controller, logic di `app/Services`
- tidak membuat breaking change tanpa changelog dan panduan migrasi
- semua perubahan publik wajib diikuti testing dan dokumentasi

## 1. Tujuan Update

Target update berikut harus menghasilkan:

- alur aplikasi frontend dan CMS tetap stabil
- security default makin ketat tanpa merusak flow user
- struktur data lebih rapi dan tidak ada perubahan schema diam-diam saat runtime
- modul CMS baru/lama tetap konsisten dengan pola existing
- testing dan dokumentasi cukup untuk release berikutnya

## 2. Constraint Teknis Wajib

Sebelum mulai implementasi, semua task harus tunduk pada constraint berikut:

1. Jangan ubah kontrak folder inti:
   - `app/`
   - `routes/`
   - `bootstrap/`
   - `public/`
   - `storage/`
   - `system/`
   - `tests/`
   - root `aiti`
2. Semua business logic baru masuk ke `app/Services`.
3. Controller hanya menangani request, validasi input dasar, pemanggilan service, dan response.
4. Query database wajib prepared statement/binding.
5. Perubahan schema hanya lewat file migrasi di `database/migrations`, bukan `ALTER TABLE` saat runtime.
6. Jika ada perubahan perilaku publik, update:
   - `CHANGELOG.md`
   - dokumen user/teknis yang relevan
7. Definisi selesai:
   - app jalan
   - security default aktif
   - CLI tetap jalan
   - tests pass
   - docs ter-update

## 3. Urutan Pengerjaan Sesuai Alur Aplikasi

## Tahap A. Baseline, Audit, dan Pengamanan Sebelum Edit

### Task A1. Audit baseline repo dan dependency

Tujuan:
- memastikan update tidak bentrok dengan kontrak `AGENT.md`
- memastikan perubahan core dan CMS tidak tercampur

Pengerjaan:
- review status kerja repo utama
- review apakah ada perubahan di `system/` dan `core/AitiCore`
- jika update core diperlukan, gunakan workflow `scripts/core-sync.ps1`

Output:
- daftar file yang memang masuk scope update
- keputusan apakah update hanya CMS atau juga sync core

### Task A2. Audit route map dan grouping modul

Tujuan:
- memastikan task update mengikuti alur user nyata

Pengerjaan:
- petakan route aktif di `routes/web.php`
- kelompokkan ke area:
  - frontend public
  - frontend auth/user area
  - payment
  - CMS auth
  - CMS dashboard
  - CMS content
  - CMS products
  - CMS file manager
  - CMS reports
  - CMS system
  - compatibility aliases

Output:
- matriks route per modul dan owner service

### Task A3. Audit risiko keamanan prioritas

Prioritas tertinggi berdasarkan codebase saat ini:

1. `app/Services/Cms/FileManagerService.php`
   - upload masih berbasis blacklist extension
   - perlu whitelist extension + verifikasi MIME nyata
   - perlu review lokasi file agar aman dari eksekusi langsung
2. `app/Services/Cms/ProductService.php`
   - ada `ensureFrontendColumns()` yang menjalankan `ALTER TABLE` saat runtime
   - harus dipindah ke migrasi
3. beberapa service lain
   - masih memakai `LIMIT {$limit}` / `OFFSET` hasil interpolasi
   - perlu distandardkan dan diamankan
4. auth/akses CMS
   - review agar pengecekan akses konsisten di middleware, bukan tercecer di controller/route

Output:
- daftar fix security yang wajib dikerjakan lebih dulu sebelum fitur tambahan

## Tahap B. Layer Bootstrap, Core, dan Kontrak Runtime

### Task B1. Verifikasi bootstrap dan middleware chain

File fokus:
- `public/index.php`
- `bootstrap/`
- `app/Middleware/StartSession.php`
- `app/Middleware/VerifyCsrfToken.php`
- `app/Middleware/CmsAuthenticate.php`

Pengerjaan:
- pastikan session start, csrf, dan auth CMS tidak regress
- verifikasi cookie policy tetap sesuai `AGENT.md`
- pastikan error handling production tidak membocorkan stack trace

Output:
- checklist runtime request lifecycle aman

### Task B2. Review CLI contract

Kontrak minimal yang tidak boleh rusak:

- `php aiti --version`
- `php aiti list`
- `php aiti serve`
- `php aiti route:list`
- `php aiti key:generate`
- `php aiti preset:bootstrap`

Pengerjaan:
- verifikasi command inti tetap berjalan
- jika ada command baru untuk update/migrasi, tetap lewat `php aiti ...`

Output:
- daftar command yang divalidasi

## Tahap C. Database dan Migrasi

### Task C1. Pindahkan perubahan schema runtime menjadi migrasi resmi

Target utama:
- hapus pola `ALTER TABLE` runtime dari service

Pengerjaan:
- identifikasi kolom yang saat ini dibuat oleh service:
  - `products.excerpt`
  - `products.modules`
  - `products.system_requirements`
  - `products.general_customers`
  - field tambahan pada modul komentar jika ada pola serupa
- buat file migrasi SQL baru di `database/migrations`
- pastikan migrasi idempotent sesuai mekanisme `php aiti migrate`

Output:
- migrasi resmi baru
- service tidak lagi memodifikasi schema saat request berjalan

### Task C2. Review seed dan konsistensi data modul

Pengerjaan:
- cek apakah seed masih kompatibel dengan modul:
  - dashboard
  - articles
  - products
  - file manager
  - youtube videos
  - reports
- pastikan data dummy mendukung uji flow frontend dan CMS terbaru

Output:
- daftar penyesuaian seed bila dibutuhkan

## Tahap D. Security Hardening

### Task D1. Hardening File Manager

File fokus:
- `app/Services/Cms/FileManagerService.php`
- `app/Controllers/Cms/FileManagerController.php`
- route asset file manager di `routes/web.php`

Pengerjaan teknis:
- ganti blacklist extension menjadi whitelist ketat
- validasi MIME dengan `finfo` atau mekanisme server-side setara
- bedakan tipe file yang benar-benar diizinkan:
  - image
  - document
  - audio/video jika memang dibutuhkan
- pastikan nama file random dan tidak mengeksekusi nama asli sebagai path
- evaluasi apakah file harus selalu disimpan di `storage/filemanager`
- pertahankan akses file lewat proxy route, bukan direct execution path
- tambahkan pembatasan ukuran upload per tipe jika perlu
- pastikan response asset memakai header aman:
  - `Content-Type`
  - `X-Content-Type-Options: nosniff`
  - cache policy yang tepat

Acceptance:
- upload file berbahaya ditolak
- file valid tetap bisa dipilih dari Media Picker
- preview frontend/CMS tidak rusak

### Task D2. Normalisasi query limit/offset

Target:
- hilangkan interpolasi numerik langsung sebanyak mungkin

Pengerjaan:
- audit service berikut:
  - `app/Services/Cms/ArticleService.php`
  - `app/Services/Cms/ClientService.php`
  - `app/Services/Cms/FileManagerService.php`
  - `app/Services/Cms/LoginLogService.php`
  - `app/Services/Cms/PageService.php`
  - `app/Services/Cms/ProductService.php`
  - `app/Services/Cms/ReportService.php`
  - `app/Services/Cms/TagService.php`
  - `app/Services/Cms/TransactionService.php`
  - `app/Services/FrontTransactionService.php`
  - `app/Services/ProductCommentService.php`
- gunakan pendekatan yang konsisten untuk integer-casting dan query building aman
- jika driver database membatasi binding pada `LIMIT`, buat helper/query builder kecil yang tetap tervalidasi ketat

Acceptance:
- seluruh query limit/offset punya pola aman dan seragam

### Task D3. Sentralisasi auth dan access control

Pengerjaan:
- review semua route CMS di `routes/web.php`
- pastikan route admin sensitif dilindungi middleware auth/role
- kurangi duplikasi pengecekan akses di controller
- verifikasi kesesuaian dengan `CMS_ALLOWED_ROLES`

Output:
- access control matrix per modul CMS

## Tahap E. Routing dan Lifecycle Request

### Task E1. Rapikan route utama dan alias kompatibilitas

Pengerjaan:
- pisahkan secara konseptual route:
  - public frontend
  - authenticated frontend
  - CMS
  - alias kompatibilitas Laravel
- review alias yang masih dipakai user lama
- pastikan tidak ada collision atau route shadowing

Output:
- route map final yang jelas

### Task E2. Review endpoint publik khusus

Endpoint yang harus dicek:
- `/.well-known/aiticore`
- `/.well-known/aiti-cms`
- `/.well-known/appspecific/com.chrome.devtools.json`
- `/sitemap.xml`
- `/notification/handler`

Pengerjaan:
- pastikan endpoint publik memang aman tanpa auth
- khusus payment notification, verifikasi signature/asal request dan logging

## Tahap F. Frontend Public Flow

Urutan ini mengikuti journey user publik.

### Task F1. Homepage dan pencarian

File fokus:
- `app/Controllers/HomeController.php`
- `app/Views/home.php`
- service article/product terkait

Pengerjaan:
- validasi data latest/published dari artikel, produk, slider, youtube, footer
- pastikan search frontend tetap aman dan performa cukup
- pastikan output tetap escaped/default secure

### Task F2. Halaman artikel, page, tag

Route fokus:
- `/read/{slug}.html`
- `/p/{slug}.html`
- `/tags/{slug}`

Pengerjaan:
- verifikasi slug handling
- verifikasi sanitasi konten editor
- verifikasi fallback not-found
- cek schema SEO jika ada

### Task F3. Halaman produk dan komentar produk

Route fokus:
- `/products/{slug}.html`
- `POST /products/{slug}/comments`

Pengerjaan:
- verifikasi galeri multi image
- verifikasi sanitasi dan validasi komentar
- pastikan status komentar tersinkron dengan modul CMS komentar
- cek relasi produk, kategori, tag, dan author

### Task F4. Cart dan payment flow

Route fokus:
- `/cart`
- `/payment`
- `/payment/orders`
- `/payment/finish`
- `/payment/reload`
- `/payment/cancel/{id}`
- `/notification/handler`

Pengerjaan:
- validasi session cart
- verifikasi harga/final amount tidak bisa dimanipulasi dari client
- audit transisi status transaksi
- review integrasi `MidtransService`
- pastikan idempotensi callback dan finish/reload flow

Acceptance:
- alur pilih produk -> cart -> payment -> status transaksi berjalan utuh

## Tahap G. Frontend Auth dan User Area

### Task G1. Login/register frontend

Route fokus:
- `/login`
- `/register`
- `/logout`

Pengerjaan:
- review validasi auth frontend
- pastikan session frontend tidak bentrok dengan CMS
- review logging/error message agar tidak bocor berlebihan

### Task G2. User dashboard area

Route fokus:
- `/users/account`
- `/users/transaction`
- `/users/transaction-details/{midtransId}`
- `/users/file`
- `/users/lainnya`

Pengerjaan:
- verifikasi akses data hanya milik user aktif
- review update profil, file premium, dan histori transaksi
- pastikan semua query berbasis user scope yang benar

## Tahap H. CMS Auth dan Dashboard

### Task H1. CMS login/register/logout

Route fokus:
- `/cms/login`
- `/cms/register`
- `/cms/logout`

Pengerjaan:
- review role restriction
- review login log
- pastikan pesan error tidak membuka detail sensitif

### Task H2. CMS dashboard dan view-sites

Route fokus:
- `/cms/dashboard`
- `/cms/view-sites`

Pengerjaan:
- validasi semua widget dashboard
- cek query latest article/product/client/transaction
- cek ringkasan identitas website dari system settings

## Tahap I. CMS Content Management

### Task I1. Articles

Route fokus:
- `/cms/articles`
- create/store/edit/update/delete

Pengerjaan:
- review CRUD artikel
- review image picker utama
- review sanitasi konten, slug, publish status

### Task I2. Posting

Route fokus:
- `/cms/posting`
- `/cms/posting/status/{id}`

Pengerjaan:
- pastikan perubahan status konsisten dengan frontend visibility

### Task I3. Pages

Route fokus:
- `/cms/pages`
- create/store/edit/update/delete

Pengerjaan:
- review slug page
- review keterhubungan dengan footer category dan frontend page route

### Task I4. Tags dan komentar global

Route fokus:
- `/cms/tags`
- `/cms/comments`

Pengerjaan:
- review input tag
- review global comment settings
- verifikasi relasi ke frontend article/product comment behavior

## Tahap J. CMS Product Flow

Urutan mengikuti operasi bisnis CMS produk.

### Task J1. Product categories

Route fokus:
- `/cms/products/categories`
- main/sub create/update/delete

Pengerjaan:
- review struktur kategori utama dan subkategori
- verifikasi efeknya ke form produk dan frontend

### Task J2. Products

Route fokus:
- `/cms/products`
- create/store/edit/update/delete

Pengerjaan:
- hapus dependensi ke `ensureFrontendColumns()`
- review field inti:
  - kode produk
  - slug
  - stok
  - harga
  - excerpt
  - content
  - modules
  - system requirements
  - general customers
  - tags
  - images
- verifikasi urutan multi image tetap terjaga
- verifikasi publish/draft terhadap frontend

### Task J3. Product comments moderation

Pengerjaan:
- sinkronkan flow komentar frontend dengan moderasi di CMS
- review action approve/reject/spam

### Task J4. Clients dan transactions

Route fokus:
- `/cms/client`
- `/cms/transactions`

Pengerjaan:
- review CRUD client
- review detail transaksi berdasarkan `midtrans_id`
- cek konsistensi relasi transaksi dengan frontend user area

## Tahap K. CMS Appearance dan Media

### Task K1. Menu appearance

Route fokus:
- `/cms/appearance/menu`

Pengerjaan:
- review menu utama dan submenu
- verifikasi efeknya ke navigasi frontend

### Task K2. Slider

Route fokus:
- `/cms/appearance/slider`

Pengerjaan:
- review image picker
- review urutan slider, CTA, dan rendering homepage

### Task K3. YouTube videos

Route fokus:
- `/cms/appearance/youtube-videos`
- `/tonton-demo`

Pengerjaan:
- review CRUD video
- review embed/render frontend
- pastikan deskripsi, thumbnail, dan autoplay control tetap stabil

### Task K4. File Manager dan Media Picker

Pengerjaan:
- setelah hardening upload selesai, validasi ulang:
  - upload
  - album
  - list
  - search
  - pagination
  - picker single/multi select
  - preview image/file
- cek backward compatibility file path legacy

## Tahap L. CMS System dan Reporting

### Task L1. System settings

Route fokus:
- `/cms/system/settings`

Pengerjaan:
- review metadata env dan database
- review field:
  - logo
  - favicon
  - meta image
  - maps embed
  - social/contact
  - footer custom
- verifikasi preview media dan maps
- pastikan sanitasi iframe maps tetap ketat

### Task L2. Access dan developer profile

Route fokus:
- `/cms/system/access`
- `/cms/system/developer-profile`

Pengerjaan:
- review update role/status user
- verifikasi hanya role berwenang yang bisa mengubah akses
- cek upload/profile asset bila ada

### Task L3. Login log

Route fokus:
- `/cms/system/log-login`

Pengerjaan:
- review pencarian/filter log
- pastikan data log cukup untuk audit tanpa mengekspos data sensitif berlebihan

### Task L4. Reports

Route fokus:
- `/cms/reports`
- `/cms/reports/ledger`
- `/cms/reports/finance`
- `/cms/reports/cash-flow`

Pengerjaan:
- review query agregasi laporan
- review form create/update ledger dan finance
- verifikasi filter periode dan total perhitungan

## Tahap M. Testing Wajib

### Task M1. Tambah/rapikan automated tests

Minimum coverage update:

- route protection CMS
- CSRF valid/invalid
- escaping output view
- file upload validation:
  - file valid diterima
  - file berbahaya ditolak
- product flow:
  - create/update tanpa runtime schema mutation
- frontend read/product/page not-found behavior
- payment callback guard minimal

File target:
- `tests/Feature/`
- `tests/Unit/` jika perlu helper/service level

### Task M2. Regression test manual

Checklist manual:

1. login CMS
2. buka dashboard
3. tambah/edit artikel
4. tambah/edit produk dengan multi image
5. upload file dari File Manager
6. update system settings media + maps
7. buka homepage, detail artikel, detail produk, page, tag
8. uji cart dan payment flow dasar
9. cek user transaction area

## Tahap N. Dokumentasi dan Release

### Task N1. Update changelog

Pengerjaan:
- tambahkan item perubahan pada `CHANGELOG.md`
- pisahkan:
  - added
  - changed
  - fixed
  - security

### Task N2. Update dokumentasi teknis dan user

Dokumen yang mungkin perlu disentuh:

- `README.md`
- `docs/USER_GUEIDE.md`
- `docs/CORE_SUBMODULE_WORKFLOW.md`
- dokumen security/test tambahan bila dibuat

### Task N3. Final release checklist

Sebelum dianggap selesai:

1. `php aiti list` valid
2. `php aiti route:list` valid
3. `php aiti migrate` valid pada database bersih
4. `composer test` pass
5. tidak ada runtime `ALTER TABLE` di service
6. upload file berbahaya tertolak
7. frontend dan CMS utama lolos smoke test
8. changelog dan docs sudah diperbarui

## 4. Prioritas Eksekusi yang Disarankan

Jika update dikerjakan bertahap, urutan prioritas praktisnya:

1. `Tahap C1` dan `Tahap D1-D3`
2. `Tahap E` sampai `Tahap G`
3. `Tahap H` sampai `Tahap L`
4. `Tahap M`
5. `Tahap N`

## 5. Catatan Implementasi

Catatan penting untuk developer:

- jangan mulai dari UI dulu jika layer schema dan security belum rapi
- jangan menambah modul baru sebelum route dan access matrix jelas
- untuk perubahan `system/`, ikuti workflow submodule agar tidak bentrok dengan core
- semua perubahan pada perilaku upload, payment, auth, dan CMS access harus dianggap high risk dan wajib dites
