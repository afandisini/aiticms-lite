# PenTest Aiticms-Lite

Dokumen ini merapikan catatan audit awal untuk proyek `Aiticms-Lite` dari sudut pandang struktur aplikasi, maintainability, dan keamanan dasar.

## Ringkasan

`Aiticms-Lite` terlihat sebagai CMS PHP ringan dengan pola arsitektur custom MVC, pemisahan service layer, dan fondasi framework internal `AitiCore-Flex`.

Secara umum, baseline ini sudah punya arah yang baik:

- struktur aplikasi cukup bersih
- logika bisnis dipisahkan ke `app/Services`
- proteksi dasar seperti CSRF dan escaping sudah tersedia
- fitur CMS inti sudah mencakup artikel, halaman, file manager, slider, tema, dan pengaturan sistem

Namun, karena sistem ini memakai core internal dan banyak logika custom, tanggung jawab keamanan dan maintenance juga berada penuh di tim pengembang.

## Kekuatan Utama

### 1. Ringan dan fokus

Karena tidak membawa beban framework besar atau ekosistem plugin yang terlalu luas, aplikasi ini lebih mudah dikendalikan dan cenderung punya request overhead yang rendah.

### 2. Service layer sudah jelas

Pemisahan controller dan service adalah keputusan yang benar. Ini memudahkan:

- audit alur bisnis
- refactor fitur
- penulisan test
- pembatasan side effect di controller

### 3. Modular

Adanya pemisahan `core/AitiCore` dan modul CMS utama memberi ruang untuk:

- menjaga boundary framework vs aplikasi
- update core tanpa membongkar seluruh modul
- membentuk baseline produk lite yang lebih mudah dirilis

### 4. Fitur inti CMS sudah cukup lengkap

Baseline saat ini sudah mencakup modul yang umum dibutuhkan untuk CMS operasional:

- file manager
- article
- page
- comment
- slider
- menu
- theme
- plugin documentation layer
- system settings

### 5. Ada indikasi kesiapan quality control

Keberadaan `tests/`, `phpunit.xml`, sanitizer HTML, CSRF middleware, dan helper escaping menunjukkan proyek ini tidak dibangun secara asal.

## Temuan Kelemahan dan Saran

| Area | Risiko / Kelemahan | Saran |
| --- | --- | --- |
| Ekosistem | Belum ada ekosistem plugin/tema pihak ketiga yang matang seperti CMS besar. | Pertahankan model terbatas, tapi sediakan kontrak hook atau event yang jelas. |
| Maintenance | Semua bug di framework internal dan layer aplikasi harus ditanggung sendiri. | Gunakan library eksternal yang matang untuk kebutuhan generik seperti HTTP client, logging, dan validation bila memang diperlukan. |
| Database | Jika query berkembang tanpa standar yang ketat, maintainability dan optimasi akan makin berat. | Pastikan semua akses database konsisten memakai prepared statement dan pola service yang dapat diaudit. |
| Dokumentasi keamanan | Catatan security tersebar dan belum menjadi checklist operasional tunggal. | Gabungkan hasil audit penting ke dokumen yang mudah dipakai saat release dan deployment. |

## Analisis Keamanan

Berdasarkan struktur proyek, beberapa fondasi keamanan sudah terlihat:

- `VerifyCsrfToken.php`
- `HtmlEditorSanitizer.php`
- `Escaper.php`
- pemisahan folder `public/` dari source utama

Itu bagus, tetapi masih ada area yang perlu dijaga ketat.

## Fokus PenTest

### 1. File Upload / File Manager

**Risiko**

- upload file berbahaya
- bypass validasi ekstensi
- remote code execution jika folder upload bisa mengeksekusi script

**Checklist**

- validasi berdasarkan MIME type, bukan hanya ekstensi
- randomize nama file upload
- batasi jenis file yang boleh diupload
- pastikan folder upload tidak bisa menjalankan PHP/script server-side
- audit alur TinyMCE upload agar tetap melewati validasi yang sama dengan File Manager

### 2. SQL Injection

**Risiko**

- query raw yang menerima input user langsung
- filter pencarian, slug, atau parameter admin yang tidak dibungkus prepared statement

**Checklist**

- semua query dinamis wajib memakai PDO prepared statement
- hindari konkatenasi string langsung untuk input user
- review service yang menerima `search`, `sort`, `slug`, `id`, dan filter admin

### 3. Session Hijacking dan Session Fixation

**Risiko**

- session cookie tidak cukup aman
- session ID tidak dirotasi setelah login

**Checklist**

- cookie session `HttpOnly`
- `Secure=true` pada production HTTPS
- `SameSite` tetap eksplisit
- `session_regenerate_id(true)` setelah login berhasil

### 4. Information Disclosure

**Risiko**

- `.env`, log, atau source internal dapat diakses dari web
- mode debug aktif di production

**Checklist**

- hanya folder `public/` yang menjadi document root
- file `.env`, `app/`, `system/`, dan storage sensitif tidak boleh expose ke publik
- `APP_DEBUG=false` pada production
- review pesan error agar tidak membocorkan stack trace sensitif

### 5. Brute Force Login CMS

**Risiko**

- serangan password guessing ke endpoint login admin

**Checklist**

- rate limiting pada login
- lockout sementara untuk percobaan gagal berulang
- CAPTCHA opsional bila diperlukan pada deployment publik
- audit logging login gagal agar bisa dipantau

### 6. XSS pada Editor dan Konten HTML

**Risiko**

- konten editor menyisipkan `<script>`
- event handler seperti `onerror`, `onclick`, atau atribut berbahaya lolos sanitizer

**Checklist**

- audit `HtmlEditorSanitizer.php`
- pastikan tag dan atribut berbahaya dibuang
- uji payload XSS umum pada artikel, halaman, slider, dan setting HTML

## Prioritas Perbaikan

### Prioritas Tinggi

- audit penuh upload file
- audit sanitizer HTML terhadap XSS
- pastikan seluruh query dinamis memakai prepared statement
- harden session login CMS

### Prioritas Menengah

- tambah checklist deployment production
- tambah monitoring login gagal
- tambah review permission untuk file manager dan tema upload

### Prioritas Lanjutan

- buat security regression test untuk upload, auth, dan sanitizer
- buat secure coding checklist internal sebelum release

## Rekomendasi Praktis Berikutnya

1. Audit `HtmlEditorSanitizer.php` dengan payload XSS nyata.
2. Review semua endpoint upload dan pastikan validasinya seragam.
3. Review `AuthController` dan session handling setelah login.
4. Pastikan `APP_DEBUG=false` di production.
5. Jalankan update dependency secara terjadwal dan review changelog security.

## Kesimpulan

`Aiticms-Lite` sudah punya fondasi arsitektur yang cukup baik untuk CMS custom yang ringan. Titik terkuatnya ada pada kesederhanaan struktur, pemisahan service layer, dan kontrol penuh atas sistem.

Titik terbesarnya sekaligus menjadi risikonya: karena sistem ini custom, maka ketahanan keamanan tidak bisa bergantung pada ekosistem besar. Kualitas security sangat ditentukan oleh disiplin audit internal, konsistensi coding, dan regression testing yang berulang.
